#!/bin/bash
./benchmark.sh \
    --generations 200 \
    --population 100 \
    --threads 12 \
    --sample-size 2000000 \
    --memory-gb 4 \
    --preset-timeout 1800 \
    --optimized-timeout 2000 \
    --optimization-timeout 259200 \
    --seed 42
