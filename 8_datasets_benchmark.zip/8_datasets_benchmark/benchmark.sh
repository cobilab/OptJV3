#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$(readlink -f "$0")")"
if ! command -v python3 >/dev/null 2>&1; then
  if ! command -v apt-get >/dev/null 2>&1; then
    echo "ERROR: python3 is missing, and apt-get is unavailable." >&2
    exit 1
  fi
  if [[ ${EUID:-$(id -u)} -eq 0 ]]; then
    apt-get update
    apt-get install -y python3
  else
    if ! command -v sudo >/dev/null 2>&1; then
      echo "ERROR: python3 is missing. Install it with your package manager." >&2
      exit 1
    fi
    sudo apt-get update
    sudo apt-get install -y python3
  fi
fi
exec python3 benchmark.py "$@"
