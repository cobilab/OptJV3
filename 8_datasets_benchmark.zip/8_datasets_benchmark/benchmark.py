#!/usr/bin/env python3
"""Reproducible, independent JARVIS3 vs cobilab/OptJV3 benchmark on Ubuntu/Linux."""
import argparse
import csv
import hashlib
import json
import os
from pathlib import Path
import re
import shlex
import shutil
import subprocess
import sys
import time
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parent
WORK = ROOT / 'work'
REPOS = WORK / 'repos'
RESULTS = ROOT / 'results'
DATA = WORK / 'datasets'
OPT = REPOS / 'OptJV3'
JV = REPOS / 'jarvis3'
ENV = {**os.environ, 'LC_ALL': 'C'}

# RefSeq accession or reproducible NCBI Entrez query. Queries are frozen to
# explicit accession lists in data/manifest.json on the first successful run.
SPEC = [
    ('sars2_ref', 'individual', ['NC_045512.2'], None, 1),
    ('mycoplasma_genitalium', 'individual', ['NC_000908.2'], None, 1),
    ('bacillus_subtilis', 'individual', ['NC_000964.3'], None, 1),
    ('ecoli_k12', 'individual', ['NC_000913.3'], None, 1),
    ('sars2_collection', 'collection', None, 'txid2697049[Organism:exp] AND 29000:31000[SLEN] AND complete genome[Title]', 40),
    ('phage_collection', 'collection', None, 'bacteriophage[Title] AND complete genome[Title] AND 20000:100000[SLEN]', 40),
    ('dna_virus_collection', 'collection', None, 'Adenoviridae[Organism:exp] AND complete genome[Title] AND 20000:40000[SLEN]', 30),
    ('mycoplasma_collection', 'collection', None, 'Mycoplasma[Organism:exp] AND complete genome[Title] AND 500000:1500000[SLEN]', 8),
]


def info(msg):
    print(msg, flush=True)


def cmd_run(argv, cwd=None, timeout=None, stdout=None, check=True):
    argv = [str(x) for x in argv]
    info('$ ' + shlex.join(argv))
    p = subprocess.run(argv, cwd=cwd, env=ENV, stdout=stdout, stderr=subprocess.STDOUT if stdout else None, timeout=timeout)
    if check and p.returncode:
        raise RuntimeError(f'Command exited {p.returncode}: {shlex.join(argv)}')
    return p.returncode


def deps():
    needed = ['git', 'gcc', 'make', 'timeout', '/usr/bin/time']
    missing = [x for x in needed if not (Path(x).exists() if x.startswith('/') else shutil.which(x))]
    if missing:
        if not shutil.which('apt-get'):
            raise RuntimeError(f'Missing required commands: {missing}; on non-Debian systems install them manually')
        pkgs = ['git', 'build-essential', 'time', 'coreutils', 'ca-certificates', 'zlib1g-dev']
        sudo = [] if os.geteuid() == 0 else ['sudo']
        if sudo and not shutil.which('sudo'):
            raise RuntimeError(f'Missing {missing}; install packages: {", ".join(pkgs)}')
        cmd_run(sudo + ['apt-get', 'update'])
        cmd_run(sudo + ['apt-get', 'install', '-y'] + pkgs)
    for name in needed:
        if not (Path(name).exists() if name.startswith('/') else shutil.which(name)):
            raise RuntimeError(f'Missing dependency after installation: {name}')


def repo(url, dest, update=False):
    if not (dest / '.git').exists():
        dest.parent.mkdir(parents=True, exist_ok=True)
        cmd_run(['git', 'clone', '--depth', '1', url, dest])
    elif update:
        cmd_run(['git', 'pull', '--ff-only'], cwd=dest)


def setup(update=False):
    deps()
    repo('https://github.com/cobilab/jarvis3.git', JV, update)
    repo('https://github.com/cobilab/OptJV3.git', OPT, update)
    jarvis = JV / 'src' / 'JARVIS3'
    optimizer = OPT / 'OptJV3'
    # The SAME JARVIS3 executable is used for all presets and by OptJV3.
    # OptJV3 may ship a separate JARVIS3 binary; it is intentionally ignored.
    cmd_run(['make', '-j', str(min(4, os.cpu_count() or 1))], cwd=JV / 'src')
    cmd_run(['make', 'release'], cwd=OPT)
    for path in (jarvis, optimizer):
        if not path.exists() or not os.access(path, os.X_OK):
            raise RuntimeError(f'Expected executable not available: {path}')
    return jarvis, optimizer


def fetch(url, method='GET', data=None, trials=5):
    for n in range(trials):
        try:
            req = urllib.request.Request(url, data=data, headers={'User-Agent': 'OptimJV3-benchmark/1.0 (research reproducibility)'}, method=method)
            with urllib.request.urlopen(req, timeout=90) as f:
                output = f.read()
            time.sleep(0.45)
            return output
        except Exception as e:
            if n == trials - 1:
                raise RuntimeError(f'NCBI request failed after retries: {url}: {e}')
            time.sleep(3 * (n + 1))


def eutils(endpoint, params, post=False):
    data = urllib.parse.urlencode(params).encode('ascii')
    url = 'https://eutils.ncbi.nlm.nih.gov/entrez/eutils/' + endpoint
    return fetch(url, 'POST' if post else 'GET', data if post else None) if post else fetch(url + '?' + data.decode())


def search_accessions(query, n):
    xml = ET.fromstring(eutils('esearch.fcgi', {'db': 'nuccore', 'term': query, 'retmax': str(min(n * 4, 250)), 'sort':'relevance', 'tool':'optimjv3_benchmark'}))
    ids = [e.text for e in xml.findall('.//IdList/Id') if e.text]
    if len(ids) < n:
        info(f'WARNING: query returned only {len(ids)} records (requested {n})')
    # Retrieve FASTA accessions from efetch header; frozen after the first build.
    return ids[:n]


def parse_fasta(raw):
    records = []
    header = None
    sequence = []
    for line in raw.decode('ascii', errors='replace').splitlines():
        if line.startswith('>'):
            if header is not None:
                records.append((header, ''.join(sequence)))
            header, sequence = line[1:].strip(), []
        elif header is not None:
            sequence.append(line.strip().upper())
    if header is not None:
        records.append((header, ''.join(sequence)))
    return records


def get_accessions_fasta(ids):
    # IDs can be either numeric Entrez identifiers or accession.version.
    # Each record is retrieved individually to make manifest mapping unambiguous.
    records = []
    for id_ in ids:
        raw = eutils('efetch.fcgi', {'db':'nuccore', 'id':id_, 'rettype':'fasta', 'retmode':'text', 'tool':'optimjv3_benchmark'})
        rec = parse_fasta(raw)
        if len(rec) != 1:
            raise RuntimeError(f'Expected one FASTA record for {id_}, got {len(rec)}')
        header, seq = rec[0]
        accession = header.split()[0]
        if len(seq) < 1000:
            raise RuntimeError(f'Unexpectedly short sequence {accession}: {len(seq)}')
        records.append((accession, header, seq))
    return records


def build_data(names):
    DATA.mkdir(parents=True, exist_ok=True)
    manifest_file = DATA / 'manifest.json'
    if manifest_file.exists():
        manifest = json.loads(manifest_file.read_text())
    else:
        manifest = {}
    for name, kind, fixed_ids, query, desired in SPEC:
        if name not in names:
            continue
        out = DATA / (name + '.seq')
        if out.exists() and out.stat().st_size > 1000 and name in manifest:
            digest = hashlib.sha256(out.read_bytes()).hexdigest()
            if digest == manifest[name].get('sha256'):
                info(f'[cache] {name}: {out.stat().st_size} symbols')
                continue
            raise RuntimeError(f'Checksum mismatch for {out}. Remove explicitly to regenerate')
        ids = fixed_ids if fixed_ids else search_accessions(query, desired)
        rec = get_accessions_fasta(ids)
        total_ambig = 0
        data = bytearray()
        accepted = []
        for acc, header, seq in rec:
            # ACGT-only input for both compressors, documented explicitly.
            normalized = re.sub('[^ACGT]', '', seq)
            total_ambig += len(seq) - len(normalized)
            if len(normalized) < 1000:
                continue
            data.extend(normalized.encode('ascii'))
            accepted.append({'accession':acc, 'original_length':len(seq), 'acgt_length':len(normalized), 'header':header})
        if not accepted or len(data) < 1000:
            raise RuntimeError(f'No valid sequence for {name}; refine Entrez query')
        # Require enough sequences for collection to be meaningful.
        if kind == 'collection' and len(accepted) < max(3, desired // 2):
            raise RuntimeError(f'Only {len(accepted)} accepted for collection {name}, desired {desired}')
        out.write_bytes(data)
        manifest[name] = {'type':kind, 'source':'NCBI Entrez nuccore', 'query':query, 'requested':desired,
                          'records':accepted, 'removed_non_ACGT':total_ambig,
                          'symbols':len(data), 'sha256':hashlib.sha256(data).hexdigest()}
        manifest_file.write_text(json.dumps(manifest, indent=2) + '\n')
        info(f'[dataset] {name}: {len(data)} symbols; {len(accepted)} records; removed {total_ambig} non-ACGT bases')
    return manifest


def sha256_file(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda: f.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def measure(binary, options, seqfile, outpath, timeout_sec, memory_gb, log, verify_output=True):
    """Compression time excludes optional decompression verification."""
    outpath.unlink(missing_ok=True)
    memkb = int(memory_gb * 1024 * 1024)
    argv = ['timeout', '--signal=TERM', '--kill-after=5s', str(timeout_sec),
            'bash', '-c', 'ulimit -v "$1"; shift; exec "$@"', 'limit', str(memkb),
            '/usr/bin/time', '-f', 'MAXRSS_KB=%M', str(binary)] + options + ['-o', str(outpath), str(seqfile)]
    start = time.monotonic()
    with log.open('w') as fh:
        process = subprocess.run(argv, cwd=ROOT, stdout=fh, stderr=subprocess.STDOUT, env=ENV)
    secs = time.monotonic() - start
    txt = log.read_text(errors='replace')
    hit = re.search(r'MAXRSS_KB=(\d+)', txt)
    maxrss_gb = round(int(hit.group(1)) / (1024 * 1024), 5) if hit else ''
    if process.returncode or not outpath.is_file() or outpath.stat().st_size == 0:
        outpath.unlink(missing_ok=True)
        status = 'timeout' if process.returncode in (124, 137) else f'failed({process.returncode})'
        return {'status':status, 'time_s':round(secs, 3), 'memory_gb':maxrss_gb}
    compressed = outpath.stat().st_size
    bps = 8 * compressed / seqfile.stat().st_size
    verified = 'not_checked'
    if verify_output:
        restored = outpath.with_suffix('.restored')
        restored.unlink(missing_ok=True)
        with log.open('a') as fh:
            fh.write('\n--- Round-trip decompression verification (excluded from compression time) ---\n')
            result = subprocess.run(['timeout', '--kill-after=5s', str(timeout_sec),
                                     str(binary), '-d', '-o', str(restored), str(outpath)],
                                    cwd=ROOT, stdout=fh, stderr=subprocess.STDOUT, env=ENV)
        verified = 'ok' if result.returncode == 0 and restored.is_file() and sha256_file(restored) == sha256_file(seqfile) else 'failed'
        restored.unlink(missing_ok=True)
    outpath.unlink(missing_ok=True)
    return {'status': 'ok' if verified != 'failed' else 'verification_failed',
            'time_s':round(secs,3), 'memory_gb':maxrss_gb, 'bytes':compressed,
            'bps':round(bps, 8), 'verified':verified}


def get_levels(binary):
    p = subprocess.run([str(binary), '-s'], capture_output=True, text=True, timeout=30)
    result = sorted({int(x) for x in re.findall(r'Level\s+(\d+)\s*:', p.stdout + p.stderr)})
    if not result:
        raise RuntimeError('Cannot detect JARVIS3 levels from -s output; inspect binary compatibility')
    return result


def parse_best_file(path):
    """Parse the documented cobilab/OptJV3 best.txt format (not OptimJV3 TSV)."""
    if not path.is_file():
        raise RuntimeError(f'OptJV3 did not produce {path}')
    text = path.read_text(errors='replace')
    if not re.search(r'\bvalid=1\b', text):
        raise RuntimeError(f'OptJV3 returned no valid candidate: {path}')
    size_match = re.search(r'\bbytes=(\d+)\b', text)
    match = re.search(r'^params:\s*(.*?)\s*$', text, re.MULTILINE)
    if not match or not size_match or int(size_match.group(1)) < 1:
        raise RuntimeError(f'Cannot parse valid OptJV3 best.txt: {path}')
    params = shlex.split(match.group(1))
    allowed = {'-hs', '-lr', '-sd', '-cm', '-rm'}
    if not params or len(params) % 2 or any(params[i] not in allowed or not params[i+1] for i in range(0, len(params), 2)):
        raise RuntimeError(f'Unexpected OptJV3 parameter string: {match.group(1)}')
    return params, int(size_match.group(1))


def prepare_optimization_sample(name, seqfile, max_bytes):
    """Deterministic, spatially distributed subsample; no sample if input <= cap.

    The output is A/C/G/T-only and has exactly max_bytes for larger inputs.
    We use at most 64 contiguous windows distributed across the whole file,
    rather than only taking the beginning of the concatenated genome collection.
    """
    size = seqfile.stat().st_size
    if size <= max_bytes:
        return seqfile, size, 'whole_file'
    sample_dir = WORK / 'samples'
    sample_dir.mkdir(parents=True, exist_ok=True)
    sample = sample_dir / f'{name}_sample_{max_bytes}.seq'
    metadata = sample.with_suffix('.json')
    source_sha = sha256_file(seqfile)
    if sample.exists() and metadata.exists():
        try:
            info_old = json.loads(metadata.read_text())
            if (info_old.get('source_sha256') == source_sha
                    and info_old.get('sample_size') == max_bytes
                    and sample.stat().st_size == max_bytes
                    and info_old.get('sample_sha256') == sha256_file(sample)):
                return sample, max_bytes, 'distributed_64_windows'
        except (OSError, ValueError):
            pass

    windows = min(64, max_bytes // 4096) or 1
    window_size, remaining = divmod(max_bytes, windows)
    windows_info = []
    with seqfile.open('rb') as r, sample.with_suffix('.seq.tmp').open('wb') as w:
        for i in range(windows):
            length = window_size + (1 if i < remaining else 0)
            lo = (i * size) // windows
            hi = ((i + 1) * size) // windows
            pos = lo + max(0, (hi - lo - length) // 2)
            r.seek(pos)
            block = r.read(length)
            if len(block) != length:
                raise RuntimeError(f'Cannot extract sample window {i} from {seqfile}')
            w.write(block)
            windows_info.append({'offset':pos, 'length':length})
    sample.with_suffix('.seq.tmp').replace(sample)
    metadata.write_text(json.dumps({
        'dataset':name, 'source':str(seqfile), 'source_bytes':size,
        'source_sha256':source_sha, 'sample_size':max_bytes,
        'sample_sha256':sha256_file(sample), 'method':'distributed_64_windows',
        'windows':windows_info
    }, indent=2) + '\n')
    return sample, max_bytes, 'distributed_64_windows'


def process_group_rss_gb(pgid):
    """Linux aggregate RSS of concurrently running optimizer and compressor processes.

    This sums per-process RSS (shared mappings may be counted more than once).
    It is a sampled approximation, not a physical-RAM or PSS guarantee.
    """
    total = 0
    try:
        names = os.listdir('/proc')
    except OSError:
        return None
    for name in names:
        if not name.isdigit():
            continue
        try:
            stat = Path('/proc', name, 'stat').read_text()
            fields = stat.rsplit(') ', 1)[1].split()
            if int(fields[2]) != pgid:  # process group ID
                continue
            resident_pages = int(Path('/proc', name, 'statm').read_text().split()[1])
            total += resident_pages * os.sysconf('SC_PAGE_SIZE')
        except (OSError, IndexError, ValueError):
            continue
    return total / (1024 ** 3)


def show_optimizer_progress(history, name, total, tracker):
    """Read only newly completed history.csv rows; each generation is flushed by C."""
    if not history.is_file():
        return
    with history.open('r', encoding='utf-8', errors='replace') as f:
        f.seek(tracker['offset'])
        content = f.read()
        if not content:
            return
        # Each history row is written with a newline and fclose() in OptJV3.
        lines = content.splitlines(keepends=True)
        completed = [line for line in lines if line.endswith('\n')]
        tracker['offset'] += sum(len(line.encode('utf-8')) for line in completed)
        for line in completed:
            if line.startswith('generation,') or not line.strip():
                continue
            try:
                row = next(csv.reader([line]))
                gen = int(row[0])
                bps = row[3]
                size = row[2]
            except (ValueError, IndexError, csv.Error):
                continue
            if gen > tracker['generation']:
                tracker['generation'] = gen
                info(f'  [{name}] geração {gen}/{total} ({100*gen/total:.1f}%)'
                     f' | melhor amostra: {bps} bps | {size} bytes')


def single_optimization(name, args, binary, optimizer):
    """Start a fresh independent GA on a sample (up to sample_size bases)."""
    seqfile = DATA / (name + '.seq')
    sample, sample_bytes, strategy = prepare_optimization_sample(name, seqfile, args.sample_size)
    info(f'  [sample] {name}: {sample_bytes:,} / {seqfile.stat().st_size:,} bases '
         f'({strategy}); compression final: ficheiro completo')
    folder = RESULTS / 'optimizer' / name
    folder.mkdir(parents=True, exist_ok=True)
    temp = folder / 'tmp'
    temp.mkdir(exist_ok=True)
    best = folder / 'best.txt'
    history = folder / 'history.csv'
    best.unlink(missing_ok=True)
    history.unlink(missing_ok=True)
    command = [str(optimizer), '--jarvis', str(binary), '--input', str(sample),
               '--population', str(args.population), '--generations', str(args.generations),
               '--threads', str(args.threads), '--seed', str(args.seed),
               '--elite', str(min(args.elite, args.population)),
               '--tournament', str(min(args.tournament, args.population)),
               '--crossover', str(args.crossover), '--mutation', str(args.mutation),
               '--toggle', str(args.toggle), '--objective', 'bytes',
               '--max-cmodels', str(args.max_cmodels), '--min-cmodels', str(args.min_cmodels),
               '--max-rmodels', str(args.max_rmodels), '--min-rmodels', str(args.min_rmodels),
               '--global-bounds', 'hs=16:48,lr=0.0:0.2,seed=1:1000',
               '--cm-bounds', 'ctx=1:13,den=1:200,ir=0:2,gamma=0.01:0.99,edits=0:3,eden=1:50,eir=0:1,egamma=0.01:0.99',
               '--rm-bounds', 'nr=1:200,ctx=11:13,beta=0.01:0.99,limit=1:20,gamma=0.01:0.99,ir=0:1,weight=0.01:0.99,cache=1:4',
               '--best-out', str(best), '--history-out', str(history), '--workdir', str(temp)]
    if args.verify_candidates:
        command.append('--verify')
    (folder/'command.txt').write_text(shlex.join(command)+'\n')
    logfile = RESULTS / 'logs' / f'{name}_optjv3.log'
    memkb = int(args.memory_gb * 1024 * 1024)
    wrapped = ['timeout','--signal=TERM','--kill-after=5s',str(args.optimization_timeout),
               'bash','-c','ulimit -v "$1"; shift; exec "$@"','limit', str(memkb)] + command
    start = time.monotonic()
    peak_gb = 0.0
    tracker = {'offset': 0, 'generation':-1}
    with logfile.open('w') as fh:
        process = subprocess.Popen(wrapped, cwd=ROOT, env=ENV, stdout=fh,
                                   stderr=subprocess.STDOUT, start_new_session=True)
        while True:
            current = process_group_rss_gb(process.pid)
            if current is not None:
                peak_gb = max(peak_gb, current)
            show_optimizer_progress(history, name, args.generations, tracker)
            try:
                code = process.wait(timeout=1)
                break
            except subprocess.TimeoutExpired:
                pass
        show_optimizer_progress(history, name, args.generations, tracker)
    duration = round(time.monotonic() - start, 3)
    if code != 0:
        label = 'timeout' if code in (124,137) else f'exit {code}'
        raise RuntimeError(f'OptJV3 {label} on {name} after {duration}s; see {logfile}')
    parameters, claimed_size = parse_best_file(best)
    return (parameters, claimed_size, duration, folder, command,
            sample_bytes, strategy, round(peak_gb, 5) if peak_gb > 0 else '')


def rows_for(name, args, binary, optimizer, levels, rows, persist):
    seq = DATA / (name + '.seq')
    logdir = RESULTS / 'logs' / name
    logdir.mkdir(parents=True, exist_ok=True)
    outdir = WORK / 'tmp'
    outdir.mkdir(parents=True, exist_ok=True)
    input_bytes = seq.stat().st_size
    for level in levels:
        # Preserve completed presets on restart, retry errors/timeouts if needed.
        if any(r['dataset']==name and r['method']=='JARVIS3_preset'
               and r.get('level')==level and r['status']=='ok' for r in rows):
            continue
        row = measure(binary, ['-l',str(level)], seq, outdir / f'{name}_l{level}.jc',
                      args.preset_timeout, args.memory_gb,
                      logdir/f'jv3_level_{level}.log', args.verify_output)
        row.update({'dataset':name, 'input_bytes':input_bytes, 'method':'JARVIS3_preset',
                    'level':level, 'optimization_s':0, 'command':f'JARVIS3 -l {level}'})
        rows[:] = [r for r in rows if not (r['dataset']==name and
                  r['method']=='JARVIS3_preset' and r.get('level')==level)]
        rows.append(row)
        persist()
        info(f'  preset {level:2}: {row.get("bps", "-")} bps ({row["status"]})')
    if not args.reoptimize and any(r['dataset']==name and r['method']=='OptJV3' and r.get('status')=='ok' for r in rows):
        info(f'  [cache] OptJV3 para {name} já concluído; resultados mantidos')
        return
    params, claimed, cost, folder, opt_command, sample_bytes, strategy, optimizer_peak = single_optimization(name, args, binary, optimizer)
    row = measure(binary, params, seq, outdir/f'{name}_opt.jc',
                  args.optimized_timeout, args.memory_gb,
                  logdir/'optjv3_final.log', args.verify_output)
    # If optimizing on only a sample, the best.txt byte count describes that
    # sample, NOT the full input: it must not be compared to the final size.
    if row['status']=='ok' and sample_bytes==input_bytes and row['bytes']!=claimed:
        row['status']='size_mismatch'
        info(f'  WARNING: OptJV3 size {claimed}, final size {row["bytes"]}; result invalid')
    row.update({'dataset':name, 'input_bytes':input_bytes, 'method':'OptJV3', 'level':'',
                'optimization_s':cost, 'optimizer_reported_bytes':claimed,
                'optimization_sample_bytes':sample_bytes, 'sample_strategy':strategy,
                'optimization_peak_ram_gb':optimizer_peak,
                'command':'JARVIS3 '+shlex.join(params),
                'optimization_command':shlex.join(opt_command),
                'best_file':str(folder/'best.txt')})
    rows[:] = [r for r in rows if not (r['dataset']==name and r['method']=='OptJV3')]
    rows.append(row)
    persist()
    info(f'  OptJV3 final: {row.get("bps", "-")} bps ({row["status"]}), '
         f'otimização={cost}s, pico RSS agregado durante otimização={optimizer_peak} GiB')


def save(rows, manifest, names, levels):
    fields = ['dataset','method','level','status','input_bytes','bytes','bps','time_s',
              'memory_gb','verified','optimization_s','optimizer_reported_bytes',
              'optimization_sample_bytes','sample_strategy','optimization_peak_ram_gb',
              'command','optimization_command','best_file']
    with (RESULTS/'all_runs.tsv').open('w',newline='') as f:
        writer = csv.DictWriter(f,fieldnames=fields,delimiter='\t',extrasaction='ignore')
        writer.writeheader()
        writer.writerows(rows)
    summary = []
    for name,*_ in SPEC:
        if name not in names:
            continue
        subset = [r for r in rows if r['dataset']==name and r['status']=='ok']
        base = next((r for r in subset if r['method']=='JARVIS3_preset' and r['level']==7),None)
        preset_all = [r for r in rows if r['dataset']==name and r['method']=='JARVIS3_preset'
                      and r.get('level') in levels]
        presets = [r for r in subset if r['method']=='JARVIS3_preset' and r.get('level') in levels]
        optimized = next((r for r in subset if r['method']=='OptJV3'),None)
        best = min(presets,key=lambda r:r['bytes']) if presets else None
        complete = len(preset_all)==len(levels) and all(r['status']=='ok' for r in preset_all)
        if optimized and best and complete:
            status = 'complete'
        elif optimized and best:
            status = 'partial_presets'
        else:
            status = 'incomplete'
        gain = round(100*(best['bytes']-optimized['bytes'])/best['bytes'],3) if optimized and best else ''
        summary.append({'dataset':name,'n_genomes':len(manifest[name]['records']),
                        'input_bytes':manifest[name]['symbols'],
                        'optimization_sample_bytes':optimized.get('optimization_sample_bytes', '') if optimized else '',
                        'default_bps':base['bps'] if base else '',
                        'default_time_s':base['time_s'] if base else '',
                        'default_peak_ram_gb':base.get('memory_gb','') if base else '',
                        'best_preset':best['level'] if best else '',
                        'best_preset_bps':best['bps'] if best else '',
                        'best_preset_time_s':best['time_s'] if best else '',
                        'best_preset_peak_ram_gb':best.get('memory_gb','') if best else '',
                        'optimized_bps':optimized['bps'] if optimized else '',
                        'optimized_time_s':optimized['time_s'] if optimized else '',
                        'optimized_peak_ram_gb':optimized.get('memory_gb','') if optimized else '',
                        'optimization_s':optimized['optimization_s'] if optimized else '',
                        'optimization_peak_ram_gb':optimized.get('optimization_peak_ram_gb','') if optimized else '',
                        'gain_pct':gain,'presets_completed':len(presets),
                        'presets_requested':len(levels),
                        'optimized_command':optimized['command'] if optimized else '',
                        'status':status})
    if not summary:
        return
    with (RESULTS/'summary.tsv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(summary[0]),delimiter='\t')
        w.writeheader()
        w.writerows(summary)
    with (RESULTS/'summary.md').open('w') as f:
        cols=['dataset','n_genomes','input_bytes','optimization_sample_bytes',
              'default_bps','default_time_s','default_peak_ram_gb',
              'best_preset','best_preset_bps','best_preset_time_s','best_preset_peak_ram_gb',
              'optimized_bps','optimized_time_s','optimized_peak_ram_gb',
              'optimization_s','optimization_peak_ram_gb','gain_pct','status']
        f.write('| '+' | '.join(cols)+' |\n| '+' | '.join(['---']*len(cols))+' |\n')
        for row in summary:
            f.write('| '+' | '.join(str(row.get(c,'')) for c in cols)+' |\n')
    valid=[s for s in summary if s['status']=='complete']
    info(f'Results: results/summary.tsv, summary.md, all_runs.tsv; complete={len(valid)}/{len(summary)}; '
         f'OptJV3 wins={sum(s["gain_pct"]>0 for s in valid)}; gain_pct é percentagem (%)')


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--generations',type=int,default=200)
    p.add_argument('--population',type=int,default=100)
    p.add_argument('--threads',type=int,default=10)
    p.add_argument('--sample-size',type=int,default=2000000,
                   help='Máximo de bases da amostra utilizada pelo OptJV3 (default: 2000000). Compressão final sempre completa.')
    p.add_argument('--seed',type=int,default=42)
    p.add_argument('--elite',type=int,default=4)
    p.add_argument('--tournament',type=int,default=3)
    p.add_argument('--crossover',type=float,default=0.85)
    p.add_argument('--mutation',type=float,default=0.12)
    p.add_argument('--toggle',type=float,default=0.08)
    p.add_argument('--min-cmodels',type=int,default=0)
    p.add_argument('--max-cmodels',type=int,default=3)
    p.add_argument('--min-rmodels',type=int,default=0)
    p.add_argument('--max-rmodels',type=int,default=2)
    p.add_argument('--levels',default='all',help='all, e.g. 1-15 or 1,3,7,10')
    p.add_argument('--preset-timeout',type=int,default=300)
    p.add_argument('--optimized-timeout',type=int,default=600)
    p.add_argument('--optimization-timeout',type=int,default=12000)
    p.add_argument('--memory-gb',type=float,default=6)
    p.add_argument('--no-verify-output',action='store_false',dest='verify_output',
                   help='Skip final compressed-file round-trip verification')
    p.add_argument('--verify-candidates',action='store_true',
                   help='Have OptJV3 verify every GA candidate; slower')
    p.add_argument('--only',default='',help='Comma-separated dataset names (download only those)')
    p.add_argument('--update-repos',action='store_true')
    p.add_argument('--reoptimize',action='store_true',
                   help='Repetir a otimização OptJV3 mesmo que exista resultado válido; mantém os presets JARVIS3')
    args=p.parse_args()
    positives=[args.generations,args.population,args.threads,args.elite,args.tournament,
               args.preset_timeout,args.optimized_timeout,args.optimization_timeout,args.sample_size]
    if min(positives)<1 or args.population<2 or args.memory_gb<=0 or any(not 0<=v<=1 for v in (args.crossover,args.mutation,args.toggle)):
        p.error('Invalid GA/timeout/memory values')
    if args.min_cmodels<0 or args.min_rmodels<0 or args.max_cmodels>16 or args.max_rmodels>8 or \
       args.min_cmodels>args.max_cmodels or args.min_rmodels>args.max_rmodels or \
       args.max_cmodels+args.max_rmodels<1:
        p.error('Invalid number of models')
    names=set(x.strip() for x in args.only.split(',') if x.strip()) if args.only else {x[0] for x in SPEC}
    if not names or names-{x[0] for x in SPEC}:
        p.error('Unknown dataset(s): '+str(names-{x[0] for x in SPEC}))
    RESULTS.mkdir(parents=True,exist_ok=True)
    (RESULTS/'logs').mkdir(parents=True,exist_ok=True)
    binary, optimizer=setup(args.update_repos)
    manifest=build_data(names)
    allowed=get_levels(binary)
    if args.levels=='all':
        levels=allowed
    elif re.fullmatch(r'\d+-\d+',args.levels):
        a,b=map(int,args.levels.split('-'));levels=[x for x in allowed if a<=x<=b]
    else:
        try: requested=[int(x) for x in args.levels.split(',')]
        except ValueError: p.error('Invalid --levels')
        levels=[x for x in requested if x in allowed]
    if not levels:
        p.error('No valid JARVIS3 preset levels selected')
    info('JARVIS3 preset levels: '+','.join(map(str,levels)))
    metadata={'run_options':vars(args),'jarvis3_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=JV,text=True).strip(),
              'optjv3_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=OPT,text=True).strip(),
              'jarvis3_sha256':sha256_file(binary),'optjv3_sha256':sha256_file(optimizer),
              'selected_levels':levels, 'python':sys.version,'platform':os.uname().sysname+' '+os.uname().release}
    checkpoint=RESULTS/'checkpoint.json'
    rows=[]
    signature={k:metadata[k] for k in ('run_options','jarvis3_commit','optjv3_commit','jarvis3_sha256','optjv3_sha256','selected_levels')}
    if checkpoint.exists():
        previous=json.loads(checkpoint.read_text())
        oldsig=previous.get('signature',{})
        if oldsig==signature:
            rows=previous['rows']
        else:
            # Safe migration of completed baseline results when adding --sample-size.
            # Do not silently accept changed binaries or datasets as comparable.
            keys=('jarvis3_commit','optjv3_commit','jarvis3_sha256','optjv3_sha256')
            if any(oldsig.get(k)!=signature[k] for k in keys):
                raise RuntimeError('Existing checkpoint uses different binaries/commits. '
                                   'Keep a separate directory for this benchmark.')
            old_opts=oldsig.get('run_options',{})
            new_opts=signature['run_options']
            ga_keys=('generations','population','threads','seed','elite','tournament',
                     'crossover','mutation','toggle','min_cmodels','max_cmodels',
                     'min_rmodels','max_rmodels','verify_candidates',
                     'memory_gb','optimization_timeout')
            # There were no sampled runs in the previous version: treat those as
            # whole-file optimizations (new sampling changes the search objective).
            ga_same=all(old_opts.get(key)==new_opts.get(key) for key in ga_keys)
            for r in previous.get('rows',[]):
                name=r.get('dataset')
                if name not in names:
                    continue
                if r.get('method')=='JARVIS3_preset' and r.get('level') in levels:
                    if r.get('status')=='ok':
                        rows.append(r)
                elif r.get('method')=='OptJV3' and r.get('status')=='ok' and ga_same:
                    size=manifest[name]['symbols']
                    old_sample=r.get('optimization_sample_bytes',size)
                    # Only carry old OptJV3 results if they genuinely optimized
                    # the same input (previously whole file, <= current cap).
                    if not args.reoptimize and old_sample==size and size <= args.sample_size:
                        r=dict(r)
                        r['optimization_sample_bytes']=size
                        r['sample_strategy']='whole_file'
                        r.setdefault('optimization_peak_ram_gb','')
                        rows.append(r)
            backup=RESULTS/'checkpoint.pre_migration.json'
            if not backup.exists():
                shutil.copy2(checkpoint,backup)
            info(f'[checkpoint] Assinatura alterada: preservados {sum(r["method"]=="JARVIS3_preset" for r in rows)} '
                 f'presets válidos e {sum(r["method"]=="OptJV3" for r in rows)} otimizações compatíveis. '
                 f'Cópia anterior em {backup.name}.')
    (RESULTS/'environment.json').write_text(json.dumps(metadata,indent=2)+'\n')
    def persist():
        temp=checkpoint.with_suffix('.json.tmp')
        temp.write_text(json.dumps({'signature':signature,'rows':rows},indent=2)+'\n')
        temp.replace(checkpoint)
        save(rows,manifest,names,levels)
    persist()
    for name,*_ in SPEC:
        if name not in names:
            continue
        info(f'\n===== DATASET {name} ({manifest[name]["symbols"]} bases) =====')
        try:
            rows_for(name,args,binary,optimizer,levels,rows,persist)
        except Exception as e:
            info('ERROR for '+name+': '+str(e))
            with (RESULTS/'errors.log').open('a') as f:
                f.write(name+': '+repr(e)+'\n')
    persist()
    if not any(r['method']=='OptJV3' and r['status']=='ok' for r in rows):
        raise SystemExit('No successful OptJV3 results: inspect results/errors.log and results/logs')


if __name__=='__main__':
    main()